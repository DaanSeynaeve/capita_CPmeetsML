For a demo, run
custom_scripts/run_experiments.sh
