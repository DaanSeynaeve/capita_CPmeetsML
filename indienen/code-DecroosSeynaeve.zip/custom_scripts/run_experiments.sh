echo 'LOAD 1:'
python mzn_feedback.py ../energychallenge-DecroosSeynaeve.mzn ../load1
echo 'LOAD 8:'
python mzn_feedback.py ../energychallenge-DecroosSeynaeve.mzn ../load8
